<?php
namespace PFBC\Element;

class Password extends Textbox {
	protected $attributes = array("type" => "password");
}
