<?php
namespace PFBC\Element;

class DateTime extends Textbox {
	protected $attributes = array("type" => "datetime");
}
