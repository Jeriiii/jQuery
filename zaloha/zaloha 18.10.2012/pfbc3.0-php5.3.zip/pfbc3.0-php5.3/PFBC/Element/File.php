<?php
namespace PFBC\Element;

class File extends \PFBC\Element {
	protected $attributes = array("type" => "file");
}
