<?php
namespace PFBC\Element;

class Search extends Textbox {
	protected $attributes = array(
		"type" => "search",
		"class" => "search-query"
	);
}
