<?php
namespace PFBC\Element;

class DateTimeLocal extends Textbox {
	protected $attributes = array("type" => "datetime-local");
}
