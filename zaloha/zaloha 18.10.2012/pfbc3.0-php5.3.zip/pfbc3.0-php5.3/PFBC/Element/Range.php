<?php
namespace PFBC\Element;

class Range extends Textbox {
	protected $attributes = array("type" => "range");
}
