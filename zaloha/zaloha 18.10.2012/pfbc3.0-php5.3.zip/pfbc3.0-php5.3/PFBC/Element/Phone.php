<?php
namespace PFBC\Element;

class Phone extends Textbox {
	protected $attributes = array("type" => "tel");
}
