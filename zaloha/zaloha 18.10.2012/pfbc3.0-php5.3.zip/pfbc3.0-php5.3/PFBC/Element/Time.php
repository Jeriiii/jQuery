<?php
namespace PFBC\Element;

class Time extends Textbox {
	protected $attributes = array("type" => "time");
}
